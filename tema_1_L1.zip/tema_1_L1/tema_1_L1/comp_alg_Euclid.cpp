﻿//12. Determinați CMMDC al lui 33449 și 55439 folosind algoritmul lui Euclid extins și determinați coeficienții Bezout.
//12.Determină inversul lui 13 în modulo 47.


#include <iostream>
#include <vector>


using namespace std;

// Funcție pentru a calcula cel mai mare divizor comun și coeficienții Bezout folosind algoritmul lui Euclid extins

vector<int> euclid(int a, int b) 
{
    vector<int> x_a = { 1, 0 };
    vector<int> x_b = { 0, 1 };

    int q;
    int r;
    while (b!=0) {
        q = a / b;
        r = a % b;
        a = b;
        b = r;

        // Calculam noii coeficienți Bezout
        vector<int> rezultat = { x_a[0] - q * x_b[0], x_a[1] - q * x_b[1] };
        x_a = x_b;
        x_b = rezultat;
    }
   
    // Returnam CMMD și coeficienții Bezout într - un vector
        vector<int> rezultate = { a, x_a[0], x_a[1] };
    return rezultate;
}

int main() {
    int numar1, numar2;

    cout << "Introduceti primul numar: ";
    cin >> numar1;

    cout << "Introduceti al doilea numar: ";
    cin >> numar2;


    // Calculăm cel mai mare divizor comun și coeficienții Bezout folosind algoritmul lui Euclid extins
    vector<int> rezultate = euclid(numar1, numar2);
    cout << "Cel mai mare divizor comun (CMMD) al numerelor (" << numar1 << "," << numar2 << ") este: " << rezultate[0] << endl;
    cout << "Coeficientii Bezout: (" << rezultate[1]<< "," << rezultate[2]<<")" << endl;
    cout << "ecuatie:  " << rezultate[1]<<"*"<< numar1<< "+"<< rezultate[2]<<"*"<<numar2<<"=1" << endl;
    if (rezultate[1] < 0) {
        cout << "inversul este:"<<numar2+rezultate[1] << endl;
    }
    else {
        cout << "inversul nr "<<numar1<< "in Z_"<<numar2<< " este:" << rezultate[1] << endl;
    }
    
    return 0;
}
